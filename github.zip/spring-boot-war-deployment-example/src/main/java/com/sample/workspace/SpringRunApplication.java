package com.sample.workspace;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRunApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRunApplication.class, args);
	}

}
